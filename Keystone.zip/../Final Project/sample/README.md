d3-chord-diagrams
=================

Example Chord Diagrams in D3

Instructions:

1. clone the repo or download the zip file

2. cd into the directory

3. python -m SimpleHTTPServer 8080 (should be available on mac or use any local server)

4. go to localhost:8080 in your favorite browser (if your favorite is not IE)

4. enjoy!!